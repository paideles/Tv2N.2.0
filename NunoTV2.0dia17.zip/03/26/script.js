// PLAYER
let hls = null

function tocar(url){

const video = document.getElementById("video")

// reset total
if(hls){
hls.destroy()
hls = null
}

video.pause()
video.removeAttribute("src")
video.load()

if(!url){
alert("Link inválido")
return
}

// HLS (m3u8)
if(url.includes(".m3u8")){

if(window.Hls && Hls.isSupported()){

hls = new Hls({
enableWorker:true,
lowLatencyMode:true,
backBufferLength:90
})

// HEADERS (IMPORTANTE PRA IPTV)
hls.config.xhrSetup = function(xhr){
xhr.setRequestHeader("User-Agent","Mozilla/5.0")
xhr.setRequestHeader("Referer","https://google.com/")
}

hls.loadSource(url)
hls.attachMedia(video)

hls.on(Hls.Events.MANIFEST_PARSED, function(){
video.play().catch(()=>{})
})

// ERRO → tenta fallback
hls.on(Hls.Events.ERROR, function(event, data){

console.log("Erro HLS:", data)

if(data.fatal){

switch(data.type){

case Hls.ErrorTypes.NETWORK_ERROR:
hls.startLoad()
break

case Hls.ErrorTypes.MEDIA_ERROR:
hls.recoverMediaError()
break

default:
hls.destroy()
video.src = url
video.play().catch(()=>{})
break

}

}

})

}else{

// iPhone / Safari
video.src = url
video.play().catch(()=>{})

}

}else{

// MP4 / TS
video.src = url
video.play().catch(()=>{})

}

// erro final
video.onerror = function(){
alert("❌ Esse canal não funciona nesse app (link bloqueado ou offline)")
console.log("Erro no vídeo:", url)
}

}

// MOSTRAR CANAIS

function mostrar(lista){

let cont = document.getElementById("conteudo")

cont.innerHTML = ""

lista.forEach(canal=>{

let card = document.createElement("div")

card.className = "card"

card.innerHTML = `
<img src="${canal.logo}">
<span>${canal.nome}</span>
`

card.onclick = ()=> tocar(canal.url)

cont.appendChild(card)

})

}


// CARREGAR IPTV

async function carregarLista(){

let url = prompt("Cole a URL da lista IPTV")

if(!url) return

// salva no celular
localStorage.setItem("iptv", url)

carregarListaSalva()

}


// CARREGAR LISTA SALVA

async function carregarListaSalva(){

let url = localStorage.getItem("iptv")

if(!url) return

let res = await fetch(url)
let txt = await res.text()

let linhas = txt.split("\n")

let canais = []

for(let i=0;i<linhas.length;i++){

if(linhas[i].includes("#EXTINF")){

let info = linhas[i]

// nome
let nome = info.split(",")[1]

// logo automático
let logoMatch = info.match(/tvg-logo="([^"]+)"/)
let logo = logoMatch ? logoMatch[1] : "https://cdn-icons-png.flaticon.com/512/149/149071.png"

// link
let link = linhas[i+1]

canais.push({
nome:nome,
logo:logo,
url:link
})

}

}

mostrar(canais)

}


// CARREGAR AUTOMATICO

window.onload = function(){

carregarListaSalva()

}